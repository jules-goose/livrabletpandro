package com.example.mapositionclean;


import android.content.pm.PackageManager;
import android.Manifest;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.location.Location;
import android.location.LocationManager;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;
import android.content.DialogInterface;
import android.provider.Settings;
import android.location.LocationListener;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import com.koushikdutta.async.future.FutureCallback;
import com.koushikdutta.ion.Ion;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;


import java.util.ArrayList;
import java.util.Locale;
import java.util.Date;

public class MainActivity extends AppCompatActivity implements LocationListener,OnMapReadyCallback {
    private static final int MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 42;
    public Location mLastLocation;
    private long mLastClickTime = 0;
    protected TextView tv;
    protected GoogleMap map;
    protected MarkerOptions markerOptions;
    protected Marker userPos;
    protected Button buttonCenter;
    protected Button buttonRefresh;
    protected LatLngBounds boundingbox;
    protected ArrayList<StationMeteo> stationMeteoList;
    protected ArrayList<Marker> markerArrayList;
    private String opwm_url = "http://api.openweathermap.org/data/2.5/box/";
    private String bBoxCity = "city?bbox=";
    private String APIKEY = "";  //CLE API OPENWEATHER

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv = (TextView) findViewById(R.id.centerlabel);
        buttonCenter = (Button) findViewById(R.id.button_center);
        buttonRefresh = (Button) findViewById(R.id.button_refresh);
        buttonCenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getLocation();
                onLocationChanged(mLastLocation);
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()),9.00f));
                getBBoxStr();
            }
        });
        buttonRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // clicking prevention, using threshold of 10000 ms
                if (SystemClock.elapsedRealtime() - mLastClickTime < 10000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();
                boundingbox = map.getProjection().getVisibleRegion().latLngBounds;
                getLocation();
                refreshData();
            }
        });


        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapView);
        mapFragment.getMapAsync(this);
        configLocation();
        getLocation();

        markerOptions = new MarkerOptions().position(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()))
                .alpha(1.0f)
                .infoWindowAnchor(.5f,1.0f)
                .title("vous etes ici").icon(getMarkerBitmapFromView("vous etes ici"));
        stationMeteoList = new ArrayList<StationMeteo>();
        markerArrayList = new ArrayList<Marker>();

    }
    protected void onStart() {
        super.onStart();
        getLocation();


    }
    @Override
    protected void onResume() {
        super.onResume();
        getLocation();

    }

    public void refreshData(){
        Log.i("Myapp", "dataRefresh: entered");
        Ion.with(getApplicationContext())
                .load(opwm_url+bBoxCity+getBBoxStr()+"&appid="+APIKEY)
                .asJsonObject()
                .setCallback(new FutureCallback<JsonObject>() {
                    @Override
                    public void onCompleted (Exception e, JsonObject result) {

                        stationMeteoList.clear();
                        if (result.get("cod").toString() == "400"){
                            return;
                        }
                        JsonArray station = (JsonArray) result.getAsJsonArray("list");
                        station.forEach(jsonElement -> {
                            stationMeteoList.add(new StationMeteo((JsonObject) jsonElement));
                        });
                        stationMeteoList.forEach(stationMeteo -> {
                            Log.i("STATION", stationMeteo.getName()+stationMeteo.getPosition().toString());
                            markerArrayList.add(map.addMarker(new MarkerOptions().position((LatLng) stationMeteo.getPosition())
                                    .alpha(1.0f)
                                    .infoWindowAnchor(.5f,1.0f)
                                    .title("Nom : "+stationMeteo.getName())
                                    .snippet("Coord : "+stationMeteo.getPosition().toString() +"\n\n " +
                                            "temp : "+stationMeteo.getTemperature() +"c°\n\n " +
                                            "temp max :" + stationMeteo.getTempmax() +"c°\r\n " +
                                            "temp min :" +stationMeteo.getTempmin() +"c°\n\n " +
                                            "temp ressenti :" +stationMeteo.getTempres() +"c°\n\n " +
                                            "pression :" +stationMeteo.getPression() +"hPa\n\n " +
                                            "humidité :" +stationMeteo.getHumidite() +"%\n\n " )
                                    .icon(getMarkerBitmapFromView(stationMeteo.getTemperature()))
                            ));

                        });


                    }
                });

    }

    private String getBBoxStr() {
        String res = "";
        res += boundingbox.northeast.longitude+","+boundingbox.northeast.latitude+","+boundingbox.southwest.longitude+","+boundingbox.southwest.latitude+",10";
        Log.i("bbox", "getBBoxStr: "+res);
        return res;
    }

    @Override
    public void onLocationChanged(Location location) {

        tv.setText(String.format(Locale.FRENCH, "Date : %s\nLatitude : %f \nLongitude : %f \nprécision (mètres) : %f",
                new Date(location.getTime()),
                location.getLatitude(),
                location.getLongitude(),
                location.getAccuracy()));

        userPos = map.addMarker(new MarkerOptions().position(new LatLng(location.getLatitude(), location.getLongitude())).icon(getMarkerBitmapFromView("vous etes ici")));

        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()),9.00f));
        boundingbox = map.getProjection().getVisibleRegion().latLngBounds;

    }


    public void onCurrentLocation(Location location){
        mLastLocation = location;
    }
    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @SuppressWarnings("MissingPermission")
    private void getLocation() {
        Log.i("MyAPP", "enter in getLocation");

        if(checkLocation() == false) {

            return;
        }

        LocationManager locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, this);

        //locationManager.requestSingleUpdate(LocationManager.GPS_PROVIDER, this, null);
        mLastLocation = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);

    }
    @SuppressWarnings("MissingPermission")
    private void configLocation() {
        Log.i("MyAPP", "enter in configLocation");

        if(checkLocation() == false) {
            return;
        }

        LocationManager locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 500, 1, this);
        mLastLocation = new Location(LocationManager.GPS_PROVIDER);
        Log.i("AAAAAAA",""+mLastLocation.getLatitude());

    }


    private boolean checkLocation() {

        // Test if GPS is enabled
        if (!isGPSLocationEnabled()) {
            showEnableGPSAlert();
        }

        if (isGPSLocationEnabled() == false) {
            Log.i("MyAPP", "GPS is not enabled");
            return false;
        }

        // Test if user have the location permissions
        if (havePermission(Manifest.permission.ACCESS_FINE_LOCATION) == false) {
            // Permission is not granted
            Log.i("MyAPP", "App do not have ACCESS_FINE_LOCATION");

            requestPermission(Manifest.permission.ACCESS_FINE_LOCATION, MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION);
            return false;
        }

        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION) {
            // If request is cancelled, the result arrays are empty.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocation();
            }
        }
    }

    private boolean havePermission(String perm) {
        return ContextCompat.checkSelfPermission(this, perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission(String perm, int code) {
        ActivityCompat.requestPermissions(this, new String[]{perm}, code);
    }

    private boolean isGPSLocationEnabled() {
        LocationManager locationManager = (LocationManager)getSystemService(Context.LOCATION_SERVICE);
        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
    }

    private void showEnableGPSAlert() {
        final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        dialog.setTitle("Enable Location")
                .setMessage("Your Locations Settings is set to 'Off'.\nPlease Enable Location to " +
                        "use this app")
                .setPositiveButton("Location Settings", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                        Intent myIntent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivity(myIntent);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface paramDialogInterface, int paramInt) {
                    }
                });

        dialog.show();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        map = googleMap;
        map.setInfoWindowAdapter(new infoWindowAdapter(this.getApplicationContext()));
        map.addMarker(markerOptions);
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude()),9.00f));

    }
    private BitmapDescriptor getMarkerBitmapFromView( String Text) {
        View view = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.infowindow, null);

        TextView tempVal = (TextView) view.findViewById(R.id.tempVal);
        tempVal.setText(Text);
        tempVal.setBackgroundColor(getResources().getColor(R.color.pos));

        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        // below line is use to create a bitmap for our
        // drawable which we have added.
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);

        // below line is use to add bitmap in our canvas.
        Canvas canvas = new Canvas(bitmap);


        view.draw(canvas);

        // after generating our bitmap we are returning our bitmap.
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
    private BitmapDescriptor getMarkerBitmapFromView( float temp) {
        View view = ((LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE)).inflate(R.layout.infowindow, null);

        TextView tempVal = (TextView) view.findViewById(R.id.tempVal);
        tempVal.setText(""+temp);
        if (temp > 25.0f){
            tempVal.setBackgroundColor(getResources().getColor(R.color.hot));
        }
        else if(temp<25.0f && temp >15.0f){
            tempVal.setBackgroundColor(getResources().getColor(R.color.warm));

        }
        else if(temp<15.0f && temp >5.0f){
            tempVal.setBackgroundColor(getResources().getColor(R.color.mild));

        }
        else if(temp<5.0f && temp >0.0f){
            tempVal.setBackgroundColor(getResources().getColor(R.color.cold));

        }
        else if(temp<0.0f ){
            tempVal.setBackgroundColor(getResources().getColor(R.color.freezing));
        }
        view.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        // below line is use to create a bitmap for our
        // drawable which we have added.
        Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);

        // below line is use to add bitmap in our canvas.
        Canvas canvas = new Canvas(bitmap);


        view.draw(canvas);

        // after generating our bitmap we are returning our bitmap.
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
    public class infoWindowAdapter implements GoogleMap.InfoWindowAdapter{
        Context context;
        LayoutInflater inflater;
        public infoWindowAdapter(Context context) {
            this.context = context;
        }
        @Override
        public View getInfoContents(Marker marker) {
            return null;
        }
        @Override
        public View getInfoWindow(Marker marker) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            // R.layout.echo_info_window is a layout in my
            // res/layout folder. You can provide your own
            View v = inflater.inflate(R.layout.stationinfo, null);

            TextView title = (TextView) v.findViewById(R.id.Title);
            TextView snippet = (TextView) v.findViewById(R.id.Snippet);
            title.setText(marker.getTitle());
            snippet.setText(marker.getSnippet());
            return v;
        }
    }
    public class StationMeteo {
        private String name ="";
        private float temp =0.0f;
        private float tempmin =0.0f;
        private float tempmax =0.0f;
        private float tempres =0.0f;
        private int pression =0;
        private int humidite =0;
        private LatLng pos;

        public StationMeteo(JsonObject data) {
            name = data.get("name").toString();
            temp = ((JsonObject)data.get("main")).get("temp").getAsFloat();
            pos = new LatLng(((JsonObject)data.get("coord")).get("Lat").getAsDouble(),((JsonObject)data.get("coord")).get("Lon").getAsDouble());
            tempmin = ((JsonObject)data.get("main")).get("temp_min")== null ?  -9999.99999f : ((JsonObject)data.get("main")).get("temp_min").getAsFloat();
            tempmax = ((JsonObject)data.get("main")).get("temp_max")== null ?  -9999.99999f : ((JsonObject)data.get("main")).get("temp_max").getAsFloat();
            tempres = ((JsonObject)data.get("main")).get("temp_res") == null ?  -9999.99999f : ((JsonObject)data.get("main")).get("temp_res").getAsFloat();
            pression = ((JsonObject)data.get("main")).get("pressure")== null ?  0 : ((JsonObject)data.get("main")).get("pressure").getAsInt();
            humidite = ((JsonObject)data.get("main")).get("humidity")== null ?  0 : ((JsonObject)data.get("main")).get("humidity").getAsInt();
        }
        public String getName()
        {
            return name;
        }
        public float getTemperature()
        {
            return temp;
        }
        public LatLng getPosition()
        {
            return pos;
        }

        public int getPression() {
            return pression;
        }

        public float getTempres() {
            return tempres;
        }

        public float getTempmax() {
            return tempmax;
        }

        public float getTempmin() {
            return tempmin;
        }

        public int getHumidite() {
            return humidite;
        }
    }
}
